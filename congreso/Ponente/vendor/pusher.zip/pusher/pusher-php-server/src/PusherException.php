<?php

namespace Pusher;

use Exception;

class PusherException extends Exception
{
}
